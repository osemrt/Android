"""
Singleton Design Pattern

Intent: Ensure that a class has a single instance, and provide a global point
of access to it.
"""


from __future__ import annotations
from threading import Lock, Thread
from typing import Optional


class Singleton:
    """
    The Singleton class defines the `getInstance` method that lets clients
    access the unique singleton instance.
    """

    _instance: Optional[Singleton] = None

    _lock: Lock = Lock()

    value: str

    def __init__(self, value: str) -> None:
        self.value = value

    @staticmethod
    def get_instance(value: str) -> Singleton:
        """
        The static method that controls the access to the singleton instance.
        
        This implementation let you subclass the Singleton class while
        keeping just one instance of each subclass around.
        """

        if not Singleton._instance:
            with Singleton._lock:
                if not Singleton._instance:
                    Singleton._instance = Singleton(value)
        return Singleton._instance

    def some_business_logic(self):
        """
        Finally, any singleton should define some business logic, which can
        be executed on its instance.
        """

        # ...


def test_singleton(value: str) -> None:
    singleton = Singleton.get_instance(value)
    print(singleton.value)


if __name__ == "__main__":
    # The client code.

    print("If you see the same value, then singleton was reused (yay!)\n"
          "If you see different values, then 2 singletons were created (booo!!)\n\n"
          "RESULT:\n")

    process1 = Thread(target=test_singleton, args=("FOO",))
    process2 = Thread(target=test_singleton, args=("BAR",))
    process1.start()
    process2.start()
