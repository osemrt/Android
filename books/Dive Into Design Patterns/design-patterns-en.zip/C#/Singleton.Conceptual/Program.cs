﻿// Singleton Design Pattern
//
// Intent: Ensure that a class has a single instance, and provide a global point
// of access to it.

using System;

namespace Singleton
{
    // The Singleton class defines the `getInstance` method that lets clients
    // access the unique singleton instance.
    class Singleton
    {
        private static Singleton _instance;

        private static object _lock = new object();

        private Singleton()
        { }

        // The static method that controls the access to the singleton instance.
        //
        // This implementation let you subclass the Singleton class while
        // keeping just one instance of each subclass around.
        public static Singleton getInstance()
        {
            lock (_lock)
            {
                return _instance ?? (_instance = new Singleton());
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // The client code.
            Singleton s1 = Singleton.getInstance();
            Singleton s2 = Singleton.getInstance();

            if (s1 == s2)
            {
                Console.WriteLine("Singleton works, both variables contain the same instance.");
            }
            else
            {
                Console.WriteLine("Singleton failed, variables contain different instances.");
            }
        }
    }
}
