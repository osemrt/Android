package com.example.fragment_part2;

public interface Communicator {
    public void respond(String string);
}
