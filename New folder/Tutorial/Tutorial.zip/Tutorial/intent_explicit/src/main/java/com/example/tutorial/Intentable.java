package com.example.tutorial;

import android.view.View;

public interface Intentable {

    public void goFirst(View view);
    public void goSecond(View view);
    public void goThird(View view);


}
